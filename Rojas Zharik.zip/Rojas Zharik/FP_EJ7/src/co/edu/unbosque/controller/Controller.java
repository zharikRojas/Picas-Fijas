package co.edu.unbosque.controller;

import java.util.Scanner;

public class Controller {

	Scanner leer;

	public Controller() {
		leer = new Scanner(System.in);
			funcionar();

		}

	public void funcionar() {
		int a;
		int b;
		int c;
		int result;
		String s = "";

		System.out.println("Ingrese un n�mero de un Digito: ");
		a = leer.nextInt();
		
		System.out.println("Ingrese otro n�mero de un Digito: ");
		b = leer.nextInt();
		
		System.out.println("Ingrese un �ltimo n�mero de un Digito: ");
		c = leer.nextInt();
	
		
		if (a>9 || b>9 || c>9){
			s = "Asegurese de que ha digitado los numeros de manera correcta";	
		}else {
			result = a + b * 10 + c * 100;
			s = "Los numeros ingresados son: "+ result;
		}
		System.out.println( s );
		
	}
}