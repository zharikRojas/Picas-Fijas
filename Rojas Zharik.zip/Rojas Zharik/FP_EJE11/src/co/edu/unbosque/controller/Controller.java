package co.edu.unbosque.controller;

import java.util.Scanner;


public class Controller {

	Scanner leer;
	
	 public Controller() {
	    leer = new Scanner (System.in);
	    funcionar ();
	  
	   
	 }
	 
	 public void funcionar() {
		
		 int a = 0;
		 int b = 0;
		 int c = 0;
		 int d = 0;
		 double x =0;
		 double y =0;
		 
		 
		 
		 System.out.println("Digite x1: ");
		 a = leer.nextInt();
		 
		 System.out.println("Digite x2: ");
		 b = leer.nextInt();
		 
		 System.out.println("Digite y1: ");
		 c = leer.nextInt();
		 
		 System.out.println("Digite y2: ");
		 d = leer.nextInt();
		 
		 x= Math.pow((b-a), 2);
		 y = Math.pow((d-c), 2);

		 Double result = Math.sqrt(x+y);
		 
		 System.out.println("La distancia entre los dos puntos es: "+result);
		 
				 
	
		 
		 
	 }
}
