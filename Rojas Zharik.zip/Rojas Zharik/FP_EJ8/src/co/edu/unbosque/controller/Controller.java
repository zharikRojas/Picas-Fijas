package co.edu.unbosque.controller;

import java.util.Scanner;
import java.text.DecimalFormat;

public class Controller {

	Scanner leer;

	public Controller() {
		leer = new Scanner(System.in);
		funcionar();
	}

	private static DecimalFormat df2 = new DecimalFormat("#.####");

	public void funcionar() {
		double m = 0.0;
		double p = 0.0;
		double pu = 0.0;
		String c = "";

		System.out.println("CONVERTIDOR DE MEDIDAS (pies y pulgadas)");

		System.out.println("Ingrese metros a convertir: ");
		m = leer.nextDouble();

		if (m > 0) {
			p = m * 3.2808;
			pu = m * 39.370;
			c = "La conversi�n de los metros ingresados es:" + "\nPulgadas: " + df2.format(pu) + "\nPies: "
					+ df2.format(p);
		} else {

			c = "Ha ingresado la informaci�n de manera incorrecta";
		}

		System.out.println(c);

	}
}