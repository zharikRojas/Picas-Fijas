package co.edu.unbosque.controller;

import java.util.Scanner;
import java.text.DecimalFormat;

public class Controller {

	Scanner leer;

	public Controller() {

		leer = new Scanner(System.in);
		funcionar();

	}

	private static DecimalFormat df2 = new DecimalFormat("###,###,###");

	public void funcionar() {
		double kilo = 0.0;
		double pesos = 0.0;
		String costo = "";

		System.out.println("PROGRAMA PARA CALCULAR EL COSTO DEL BOLETO DEPENDIENDO DE LOS KM A RECORRER");

		System.out.println("\nDigite kilometros a recorrer:");
		kilo = leer.nextDouble();
		if (kilo > 0) {
			pesos = kilo * 120;
			costo = "El costo de su boleto es: " +"$"+ df2.format(pesos);

		} else {
			costo = "Se�or usuario, ha ingresado la informacion incorrecta";
		}

		System.out.println(costo);

	}

}
