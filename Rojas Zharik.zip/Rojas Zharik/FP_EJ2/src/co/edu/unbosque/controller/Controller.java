package co.edu.unbosque.controller;

import java.util.Scanner;
import java.text.DecimalFormat;

public class Controller {

	Scanner leer;

	public Controller() {

		leer = new Scanner(System.in);
		funcionar();

	}

	private static DecimalFormat df2 = new DecimalFormat("#.##");

	public void funcionar() {
		double anual = 0.0;
		double mensual = 0.0;
		String resultado = "";

		System.out.println("PROGRAMA PARA SABER SU INTERES MENSUAL");
		System.out.println("Recuerde que solo puede ingresar 2 digitos");

		System.out.println("\nDigite su Interes Anual:");
		anual = leer.nextInt();

		if (anual > 0 && anual <= 100) {
			mensual = anual / 100 / 12 * 100;
			resultado = "Su interes mensual es: " +df2.format(mensual) + "%";

		} else {
			resultado = "Apreciado usuario, ha digitado la informaci�n de manera incorrecta";

		}

		System.out.println(resultado);

	}
}
