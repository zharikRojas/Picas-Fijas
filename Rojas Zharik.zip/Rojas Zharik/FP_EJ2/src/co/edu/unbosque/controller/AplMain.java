package co.edu.unbosque.controller;

public class AplMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Controller control = new Controller ();
		

	}

}
