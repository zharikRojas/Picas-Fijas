package co.edu.unbosque.controller;

import java.util.Scanner;

public class Controller {

	Scanner leer;

	public Controller() {
		leer = new Scanner(System.in);
		funcionar();
	}

	public void funcionar() {
		double radio = 0.0;
		double altura = 0.0;
		double volumen = 0.0;
		String resultado = "";

		System.out.println("PROGRAMA QUE CALCULA EL VOLUMEN DE UN CILINDRO");
		System.out.println("Mediante el ingreso del radio y la altura");
		System.out.println("Donde el radio y la altura inresada debe ser un entero positivo");

		// leer radio
		System.out.println("\nDigite radio: ");
		radio = leer.nextDouble();

		// leer altura
		System.out.println("Digite altura: ");
		altura = leer.nextDouble();

		// calcular la formula
		if (radio >= 0 && altura > 0) {
			volumen = radio * radio * altura * Math.PI;
			resultado = "El volumen es: " + volumen;
		} else {
			resultado = "Usuario, usted ingreso la informaci�n incorrecta";
		}

		// Imprimir informacion
		System.out.println(resultado);

	}

}
