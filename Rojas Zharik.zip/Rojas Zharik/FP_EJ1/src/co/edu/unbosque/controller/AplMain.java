package co.edu.unbosque.controller;

public class AplMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Controller control = new Controller();
		
	}

	
}
