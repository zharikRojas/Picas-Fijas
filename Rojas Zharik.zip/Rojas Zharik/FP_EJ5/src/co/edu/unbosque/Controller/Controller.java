package co.edu.unbosque.Controller;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Controller {

	Scanner leer;

	public Controller() {

		leer = new Scanner(System.in);
		funcionar();
	}

	private static DecimalFormat df2 = new DecimalFormat("###,###,###.##");

	public void funcionar() {
		int mon = 0;
		int ur = 0;
		int pe = 0;
		int tra = 0;
		String reparticion = "";

		System.out.println("PROGRAMA PARA CALCULAR EL PORCENTAJE CORRESPONDIENTE PARA CADA AREA DE UN HOSPITAL");
		System.out.println("");

		System.out.println("\nIngrese monto presupuestal:");
		mon = leer.nextInt();

		if (mon > 0) {
			ur = (mon * 37) / 100;
			pe = (mon * 42) / 100;
			tra = (mon * 21) / 100;
			reparticion = "La repartici�n del monto presupuestal queda de la siguiente manera: "
					+ "\nArea de Urgencias: " + "$" + df2.format(ur) + "\nArea de Pediatria: " + "$" + df2.format(pe)
					+ "\nArea de Traumatologia: " + "$" + df2.format(tra);
		} 
		
		else {
			reparticion = "Ha digitado un monto incorrecto";
		}
		System.out.println(reparticion);
	}

}
