package co.edu.unbosque.controller;
import java.util.Scanner;
import java.text.DecimalFormat;

public class Controller {

	Scanner leer;
	
	 public Controller() {
	    leer = new Scanner (System.in);
	    funcionar ();
}
	 private static DecimalFormat df2 = new DecimalFormat ("###,###");
	 public void funcionar() {
		 
		 int w = 0;
		 int t = 0;
		 double d = 0.0;
		 
		 System.out.println("Digite aceleraci�n: ");
		 w = leer.nextInt();
		 
		 System.out.println("Digite tiempo en segundos: ");
		 t = leer.nextInt();
		 
		 d = (double)(w * Math.pow((double)t, 2)) / 2;
		 
		 System.out.println("La distancia recorrida es:" +df2.format(d));
	   }
	 }
