package co.edu.unbosque.controller;

import java.util.Scanner;



public class Controller {

	Scanner leer;
	
	 public Controller() {
	    leer = new Scanner (System.in);
	    funcionar ();
	
}
	public void funcionar() {
		int p = 0;
		double g = 0.0;
		double l = 0.0;
		double t = 0.0;
		String c = "";
		
		System.out.println("Ingrese su peso en Kg: ");
		p = leer.nextInt();
		if (p>0) {
			g = (double) p * 1000;
			l = (double)p *  2.2046;
			t = (double)p / 1000;
			c = "La conversi�n queda de la siguiente manera:" 
			+ ("\nGramos: " +g)
			+ ("\nLibras: "+l)
			+ ("\nToneladas: "+t);
			
		}
		else {
			c = "Apreciado usuario asegurese de digitar la informaci�n correctamente";
		}
		System.out.println(c);
	

       }
}