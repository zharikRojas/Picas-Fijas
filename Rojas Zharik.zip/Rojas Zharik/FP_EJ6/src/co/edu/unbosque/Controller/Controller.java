package co.edu.unbosque.Controller;

import java.util.Scanner;
import java.text.DecimalFormat;

public class Controller {

	Scanner leer;

	public Controller() {
		leer = new Scanner(System.in);
		funcionar();
	}

	private static DecimalFormat df2 = new DecimalFormat("###,###,###.##");

	public void funcionar() {
		int hora = 0;
		int min = 0;
		int seg = 0;
		int segh = 0;
		int segm = 0;
		int sum = 0;
		double pro = 0.0;
		String costo = "";

		System.out.println("Digite horas: ");
		hora = leer.nextInt();

		System.out.println("Digite minutos: ");
		min = leer.nextInt();

		System.out.println("Digite segundos: ");
		seg = leer.nextInt();
		if (hora >= 0 && min >= 0 && seg >= 0) {
			segh = hora * 3600;
			segm = min * 60;
			sum = segh + segm + seg;
			pro = sum * 3.25;
			costo = "El costo del proceso es: " + "$" +df2.format(pro);
		}

		else {
			costo = " Apreciado usuario, ha digitado la informaci�n de manera incorrecta";

		}

		System.out.println(costo);

	}

}
