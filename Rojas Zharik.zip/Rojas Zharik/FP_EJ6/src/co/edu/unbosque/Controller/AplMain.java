	
package co.edu.unbosque.Controller;
public class AplMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Controller control = new Controller();
	
				
	}

}
