package co.edu.unbosque.Controller;

import java.util.Scanner;
import java.text.DecimalFormat;

public class Controller {

	Scanner leer;

	public Controller() {

		leer = new Scanner(System.in);
		funcionar();

	}
	private static DecimalFormat df2 = new DecimalFormat("###.##");	
	public void funcionar() {
		int col = 0;
		double dol = 0.0;
		double euro = 0.0;
		String cambio = "";

		System.out.println("PROGRAMA PARA HACER CAMBIO DE MONEDA");
		System.out.println("====================================");

		System.out.println("\nIngrese valor en pesos colombianos:");
		col = leer.nextInt();

		if (col > 0) {
			dol = (double) col * 1 / 2950;
			euro = (double) col * 1 / 3450;
			cambio = "\nEl cambio de pesos colombianos en:" + "\n Dolares es: " + df2.format(dol) + "\n Euros es: "
					+ df2.format(euro);

		} else {
			cambio = "Usuario, ha digitado de manera incorrecta la informaci�n";
		}

		System.out.println(cambio);

	}
}
