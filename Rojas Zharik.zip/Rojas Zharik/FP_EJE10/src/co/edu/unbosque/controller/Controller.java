package co.edu.unbosque.controller;

import java.util.Scanner;

public class Controller {

	Scanner leer;
	
	 public Controller() {
	    leer = new Scanner (System.in);
	    funcionar ();
	    
}
	 
	 public void funcionar() {
		 
		int ta = 0;
		int tp = 0;
		int tpo = 0;
		int tv = 0;
		String t = "";
		
		System.out.println("Digite total de animales:");
		ta =  leer.nextInt();
				
		System.out.println("Digite total de patas:");
		tp = leer.nextInt();
		
		if (ta > 0 && tp > 0 && tp > ta) {
			tpo = ((4 * ta)- tp) / 2;
			
			tv = ta - tpo;
			t = "El Total de Pollos es: "+tpo
			     + "\nEl total de Vacas es: "+tv;
		}
		else {
			t = "Ha digitado de manera incorrecta la informaci�n";
		}
		
		System.out.println(t);
		
		 
	    }
	 }